package com.studyhub.app.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.studyhub.app.R
import com.studyhub.app.data.model.UserProfile
import com.studyhub.app.data.repository.AuthException
import com.studyhub.app.data.repository.AuthRepository
import com.studyhub.app.util.AuthError
import com.studyhub.app.util.AuthField
import com.studyhub.app.util.Validators
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AuthUiState(
    val name: String = "",
    val email: String = "",
    val password: String = "",
    val dateOfBirth: String = "",
    val qualification: String = "",
    val yearOfStudy: String = "",
    val passwordVisible: Boolean = false,
    val loading: Boolean = false,
    val nameError: Int? = null,
    val emailError: Int? = null,
    val passwordError: Int? = null,
    val dobError: Int? = null,
    val studyError: Int? = null,
    val generalError: Int? = null,
    val infoMessage: Int? = null,
    val signedIn: Boolean = false,
    val registrationComplete: Boolean = false,
    val profile: UserProfile? = null
) {
    val passwordStrength: Int get() = Validators.passwordStrength(password)
}

class AuthViewModel(
    private val repo: AuthRepository = AuthRepository()
) : ViewModel() {

    private val _state = MutableStateFlow(AuthUiState(signedIn = repo.isLoggedIn()))
    val state: StateFlow<AuthUiState> = _state.asStateFlow()

    fun onNameChange(value: String) = _state.update {
        it.copy(name = value, nameError = null, generalError = null)
    }

    fun onEmailChange(value: String) = _state.update {
        it.copy(email = value, emailError = null, generalError = null)
    }

    fun onPasswordChange(value: String) = _state.update {
        it.copy(password = value, passwordError = null, generalError = null)
    }

    fun onDobChange(value: String) = _state.update {
        it.copy(dateOfBirth = value, dobError = null)
    }

    fun onQualificationChange(value: String) = _state.update {
        it.copy(qualification = value, studyError = null)
    }

    fun onYearOfStudyChange(value: String) = _state.update {
        it.copy(yearOfStudy = value, studyError = null)
    }

    fun onRegistrationHandled() = _state.update {
        it.copy(registrationComplete = false)
    }

    fun consumeRegistrationComplete() {
        _state.update {
            it.copy(registrationComplete = false)
        }
    }

    fun togglePasswordVisibility() = _state.update { it.copy(passwordVisible = !it.passwordVisible) }

    fun clearMessages() = _state.update {
        it.copy(
            generalError = null,
            infoMessage = null,
            emailError = null,
            passwordError = null,
            nameError = null,
            dobError = null,
            studyError = null
        )
    }

    fun register(qualification: String, yearOfStudy: String) {
        val s = _state.value
        if (s.loading) return

        clearMessages()

        val year = yearOfStudy.toIntOrNull()

        if (qualification.trim().length !in 2..120 ||
            year == null || year !in 1..8
        ) {
            _state.update {
                it.copy(generalError = R.string.registration_study_error)
            }
            return
        }

        var valid = true

        if (!Validators.isValidName(s.name)) {
            _state.update {
                it.copy(nameError = R.string.error_name_invalid)
            }
            valid = false
        }

        if (!Validators.isValidEmail(s.email)) {
            _state.update {
                it.copy(emailError = R.string.error_email_invalid)
            }
            valid = false
        }

        if (!Validators.isValidPassword(s.password)) {
            _state.update {
                it.copy(passwordError = R.string.error_password_invalid)
            }
            valid = false
        }

        if (s.dateOfBirth.isBlank()) {
            _state.update {
                it.copy(dobError = R.string.error_dob_required)
            }
            valid = false
        } else if (!Validators.isValidDateOfBirth(s.dateOfBirth)) {
            _state.update {
                it.copy(dobError = R.string.error_minimum_age)
            }
            valid = false
        }

        if (!valid) return

        _state.update {
            it.copy(
                loading = true,
                generalError = null,
                registrationComplete = false
            )
        }

        viewModelScope.launch {
            repo.register(
                name = s.name,
                email = s.email,
                password = s.password,
                dateOfBirth = s.dateOfBirth,
                qualification = qualification,
                yearOfStudy = year.toString()
            ).onSuccess {
                _state.value = AuthUiState(
                    email = s.email.trim(),
                    password = "",
                    signedIn = false,
                    registrationComplete = true,
                    infoMessage = R.string.registration_login_required
                )
            }.onFailure { error ->
                applyError(error)
            }
        }
    }

    fun login(
        context: Context? = null,
        saveCredentials: Boolean = false
    ) {
        val s = _state.value
        if (s.loading) return

        clearMessages()
        var valid = true

        if (!Validators.isValidEmail(s.email)) {
            _state.update {
                it.copy(emailError = R.string.error_login_email_format)
            }
            valid = false
        }

        if (s.password.isBlank()) {
            _state.update {
                it.copy(passwordError = R.string.error_password_required)
            }
            valid = false
        }

        if (!valid) return

        _state.update {
            it.copy(loading = true, generalError = null)
        }

        viewModelScope.launch {
            repo.login(s.email, s.password)
                .onSuccess { profile ->
                    if (saveCredentials && context != null) {
                        try {
                            val manager =
                                androidx.credentials.CredentialManager.create(context)

                            val request =
                                androidx.credentials.CreatePasswordRequest(
                                    id = s.email.trim(),
                                    password = s.password
                                )

                            manager.createCredential(
                                context = android.content.MutableContextWrapper(context),
                                request = request
                            )
                        } catch (
                            _: androidx.credentials.exceptions.CreateCredentialException
                        ) {
                            // Cancelling or failing to save must not block login.
                            android.widget.Toast.makeText(
                                context,
                                R.string.login_save_unavailable,
                                android.widget.Toast.LENGTH_LONG
                            ).show()
                        }
                    }

                    _state.update {
                        it.copy(
                            loading = false,
                            signedIn = true,
                            profile = profile,
                            password = "",
                            infoMessage = R.string.auth_login_success
                        )
                    }
                }
                .onFailure { error ->
                    applyError(error)
                }
        }
    }

    /** Called when the email field loses focus on the login screen. */
    fun checkEmailRegistered() {
        val email = _state.value.email
        if (!Validators.isValidEmail(email)) return
        viewModelScope.launch {
            if (!repo.emailExists(email)) {
                _state.update { it.copy(emailError = R.string.error_email_unregistered) }
            }
        }
    }

    fun signInWithGoogle(context: Context) = viewModelScope.launch {
        _state.update { it.copy(loading = true, generalError = null) }
        repo.signInWithGoogle(context)
            .onSuccess { profile ->
                _state.update {
                    it.copy(
                        loading = false,
                        signedIn = true,
                        profile = profile,
                        infoMessage = R.string.auth_login_success
                    )
                }
            }
            .onFailure { e -> applyError(e) }
    }

    fun sendPasswordReset() {
        val email = _state.value.email
        if (!Validators.isValidEmail(email)) {
            _state.update { it.copy(emailError = R.string.error_email_required_first) }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            repo.sendPasswordReset(email)
                .onSuccess {
                    _state.update {
                        it.copy(loading = false, infoMessage = R.string.auth_reset_sent)
                    }
                }
                .onFailure { e -> applyError(e) }
        }
    }

    fun signOut() {
        repo.signOut()
        _state.value = AuthUiState()
    }

    /** Keeps a resource id in state so errors are rendered in the current app language. */
    private fun applyError(e: Throwable) {
        val error = (e as? AuthException)?.error
            ?: AuthError(AuthField.GENERAL, R.string.error_generic)
        _state.update {
            when (error.field) {
                AuthField.EMAIL -> it.copy(loading = false, emailError = error.messageResId)
                AuthField.PASSWORD -> it.copy(loading = false, passwordError = error.messageResId)
                AuthField.NAME -> it.copy(loading = false, nameError = error.messageResId)
                AuthField.DATE_OF_BIRTH -> it.copy(loading = false, dobError = error.messageResId)
                AuthField.GENERAL -> it.copy(loading = false, generalError = error.messageResId)
            }
        }
    }
}
