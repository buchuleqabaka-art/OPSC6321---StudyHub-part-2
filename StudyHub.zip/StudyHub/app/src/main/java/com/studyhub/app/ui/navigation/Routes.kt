package com.studyhub.app.ui.navigation

object Routes {
    const val ATTENDANCE = "attendance"
    const val POLLS = "polls"
    const val WELCOME = "welcome"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val HOME = "home"
    const val GROUP_DETAIL = "group_detail"
    const val GROUPS = "groups"
    const val TASKS = "tasks"
    const val CALENDAR = "calendar"
    const val SESSIONS = "sessions"
    const val CHATS = "chats"
    const val PROFILE = "profile"
    const val PAST_PAPERS = "past_papers"
    const val PAPERS = "papers"
}