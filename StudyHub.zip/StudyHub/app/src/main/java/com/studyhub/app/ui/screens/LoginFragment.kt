package com.studyhub.app.ui.screens

import android.os.Bundle
import android.view.View
import androidx.core.widget.doAfterTextChanged
import com.google.android.material.snackbar.Snackbar
import com.studyhub.app.R
import com.studyhub.app.databinding.FragmentLoginBinding
import com.studyhub.app.ui.navigation.Routes

class LoginFragment : HubFragment(R.layout.fragment_login) {

    private var lastMessage: String? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val binding = FragmentLoginBinding.bind(view)

        val initial = authViewModel.state.value

        binding.emailInput.setText(initial.email)
        binding.passwordInput.setText("")

        binding.buttonBack.setOnClickListener {
            navigator.navigate(
                Routes.WELCOME,
                clearBackStack = true
            )
        }

        binding.textCreateAccount.setOnClickListener {
            navigator.navigate(Routes.REGISTER)
        }

        binding.textForgotPassword.setOnClickListener {
            authViewModel.onEmailChange(
                binding.emailInput.text?.toString().orEmpty()
            )
            authViewModel.sendPasswordReset()
        }

        binding.buttonLogin.setOnClickListener {

            val email = binding.emailInput.text?.toString().orEmpty()
            val password = binding.passwordInput.text?.toString().orEmpty()

            authViewModel.onEmailChange(email)
            authViewModel.onPasswordChange(password)

            authViewModel.login(
                requireContext(),
                saveCredentials = false
            )
        }

        binding.buttonGoogle.setOnClickListener {
            authViewModel.signInWithGoogle(requireActivity())
        }

        binding.emailInput.doAfterTextChanged {
            authViewModel.onEmailChange(it?.toString().orEmpty())
        }

        binding.passwordInput.doAfterTextChanged {
            authViewModel.onPasswordChange(it?.toString().orEmpty())
        }

        binding.emailInput.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                authViewModel.checkEmailRegistered()
            }
        }

        observe(authViewModel.state) { state ->

            binding.emailLayout.error =
                state.emailError?.let(::getString)

            binding.passwordLayout.error =
                state.passwordError?.let(::getString)

            binding.loginProgress.visibility =
                if (state.loading) View.VISIBLE else View.GONE

            binding.buttonLogin.isEnabled = !state.loading
            binding.buttonGoogle.isEnabled = !state.loading

            binding.textGeneralError.visibility =
                if (state.generalError == null) View.GONE else View.VISIBLE

            binding.textGeneralError.text =
                state.generalError?.let(::getString).orEmpty()

            if (state.signedIn) {
                navigator.navigate(
                    Routes.HOME,
                    clearBackStack = true
                )
            }

            val message = (state.infoMessage ?: state.generalError)
                ?.let(::getString)

            if (!message.isNullOrBlank() && message != lastMessage) {
                lastMessage = message

                Snackbar.make(
                    binding.root,
                    message,
                    Snackbar.LENGTH_LONG
                ).show()
            }
        }
    }
}
