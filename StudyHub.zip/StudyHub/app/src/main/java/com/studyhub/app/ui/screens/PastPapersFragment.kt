package com.studyhub.app.ui.screens

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import com.google.firebase.storage.StorageReference
import com.studyhub.app.R
import com.studyhub.app.ui.navigation.Routes
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

class PastPapersFragment : HubFragment(R.layout.fragment_past_papers) {

    companion object {
        private const val MAX_BYTES = 10L * 1024L * 1024L
    }

    private val auth = FirebaseAuth.getInstance()

    private var groupId: String? = null
    private var accountId: String? = null
    private var nextPageToken: String? = null
    private var busy = false

    private data class Paper(
        val reference: StorageReference,
        val title: String,
        val size: Long
    )

    private val papers = mutableListOf<Paper>()

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null && view != null && !busy) {
            upload(uri)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Capture the group so an upload cannot switch groups midway.
        groupId = savedInstanceState?.getString("paperGroup")
            ?: mainViewModel.state.value.activeGroupId
            ?: mainViewModel.state.value.planningGroupId
            ?: mainViewModel.state.value.groups.firstOrNull()?.id

        accountId = auth.currentUser?.uid

        papers.clear()
        nextPageToken = null
        busy = false

        view.findViewById<MaterialButton>(R.id.papers_back)
            .setOnClickListener {
                navigator.navigate(Routes.HOME, clearBackStack = true)
            }

        view.findViewById<MaterialButton>(R.id.papers_upload)
            .setOnClickListener {
                if (hasSession() && !busy) {
                    picker.launch(arrayOf("application/pdf"))
                }
            }

        view.findViewById<MaterialButton>(R.id.papers_refresh)
            .setOnClickListener {
                loadPapers(reset = true)
            }

        view.findViewById<MaterialButton>(R.id.papers_more)
            .setOnClickListener {
                loadPapers(reset = false)
            }

        if (hasSession()) {
            loadPapers(reset = true)
        } else {
            setStatus(R.string.choose_group_first)
            updateControls()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putString("paperGroup", groupId)
        super.onSaveInstanceState(outState)
    }

    private fun hasSession(): Boolean =
        !groupId.isNullOrBlank() &&
            accountId != null &&
            auth.currentUser?.uid == accountId

    private fun checkSession() {
        check(hasSession()) { "Account or group changed" }
    }

    private fun folder(): StorageReference {
        checkSession()

        return FirebaseStorage.getInstance()
            .reference
            .child("group-papers")
            .child(requireNotNull(groupId))
    }

    private fun setStatus(message: Int) {
        view?.findViewById<TextView>(R.id.papers_status)
            ?.setText(message)
    }

    private fun updateControls() {
        val root = view ?: return
        val enabled = !busy && hasSession()

        root.findViewById<MaterialButton>(R.id.papers_upload)
            .isEnabled = enabled

        root.findViewById<MaterialButton>(R.id.papers_refresh)
            .isEnabled = enabled

        root.findViewById<MaterialButton>(R.id.papers_more).apply {
            isEnabled = enabled
            visibility = if (nextPageToken == null) {
                View.GONE
            } else {
                View.VISIBLE
            }
        }

        root.findViewById<ProgressBar>(R.id.papers_progress)
            .visibility = if (busy) View.VISIBLE else View.GONE
    }

    private suspend fun readPage(reset: Boolean) {
        checkSession()

        val reference = folder()
        val token = if (reset) null else nextPageToken

        val result = if (token == null) {
            reference.list(30).await()
        } else {
            reference.list(30, token).await()
        }

        val loaded = mutableListOf<Paper>()

        for (item in result.items) {
            val metadata = item.metadata.await()

            loaded.add(
                Paper(
                    reference = item,
                    title = metadata.getCustomMetadata("title")
                        ?.takeIf { it.isNotBlank() }
                        ?: item.name,
                    size = metadata.sizeBytes
                )
            )
        }

        checkSession()

        if (reset) papers.clear()

        val existingPaths = papers.map { it.reference.path }.toSet()

        papers.addAll(
            loaded.filterNot { it.reference.path in existingPaths }
        )

        nextPageToken = result.pageToken
        renderPapers()
    }

    private fun loadPapers(reset: Boolean) {
        if (busy || !hasSession()) return

        busy = true
        updateControls()
        setStatus(R.string.papers_loading)

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                readPage(reset)

                if (papers.isEmpty()) {
                    setStatus(R.string.papers_empty)
                } else {
                    view?.findViewById<TextView>(R.id.papers_status)
                        ?.text = ""
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                setStatus(R.string.papers_failed)
            } finally {
                busy = false
                updateControls()
            }
        }
    }

    private fun upload(uri: Uri) {
        if (busy || !hasSession()) return

        busy = true
        updateControls()
        setStatus(R.string.papers_uploading)

        val appContext = requireContext().applicationContext

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val selected = withContext(Dispatchers.IO) {
                    val resolver = appContext.contentResolver

                    val name = runCatching {
                        resolver.query(
                            uri,
                            arrayOf(OpenableColumns.DISPLAY_NAME),
                            null,
                            null,
                            null
                        )?.use { cursor ->
                            if (cursor.moveToFirst()) {
                                cursor.getString(0)
                            } else {
                                null
                            }
                        }
                    }.getOrNull()
                        ?.trim()
                        ?.takeIf { it.isNotBlank() }
                        ?.take(160)
                        ?: appContext.getString(
                            R.string.papers_default_name
                        )

                    val bytes = resolver.openInputStream(uri)?.use { input ->
                        val output = ByteArrayOutputStream()
                        val buffer = ByteArray(8192)

                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break

                            require(output.size().toLong() + count <= MAX_BYTES)
                            output.write(buffer, 0, count)
                        }

                        output.toByteArray()
                    } ?: throw IllegalArgumentException("Cannot read PDF")

                    require(
                        bytes.size >= 5 &&
                            String(bytes, 0, 5, Charsets.US_ASCII) == "%PDF-"
                    )

                    name to bytes
                }

                checkSession()

                val destination = folder().child(
                    "${UUID.randomUUID()}.pdf"
                )

                val metadata = StorageMetadata.Builder()
                    .setContentType("application/pdf")
                    .setCustomMetadata("title", selected.first)
                    .setCustomMetadata(
                        "uploadedBy",
                        requireNotNull(accountId)
                    )
                    .build()

                val task = destination.putBytes(
                    selected.second,
                    metadata
                )

                try {
                    task.await()
                } finally {
                    if (!task.isComplete) task.cancel()
                }

                checkSession()

                // Upload and listing are separate operations. A refresh
                // failure must not suggest uploading the same file again.
                try {
                    readPage(reset = true)
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                    // The paper is already stored. Refresh can retry listing.
                }

                setStatus(R.string.papers_uploaded)
            } catch (e: CancellationException) {
                throw e
            } catch (_: IllegalArgumentException) {
                setStatus(R.string.papers_invalid)
            } catch (_: Exception) {
                setStatus(R.string.papers_failed)
            } finally {
                busy = false
                updateControls()
            }
        }
    }

    private fun renderPapers() {
        val box = view?.findViewById<LinearLayout>(R.id.papers_list)
            ?: return

        box.removeAllViews()

        papers.forEach { paper ->
            box.addView(
                MaterialButton(requireContext()).apply {
                    text = getString(R.string.papers_open, paper.title)

                    setOnClickListener {
                        if (!busy && hasSession()) {
                            openPaper(paper)
                        }
                    }
                }
            )

            box.addView(
                TextView(requireContext()).apply {
                    text = getString(
                        R.string.papers_details,
                        (paper.size + 1023) / 1024
                    )
                    setPadding(0, 0, 0, 16)
                }
            )
        }
    }

    private fun openPaper(paper: Paper) {
        if (busy || !hasSession()) return

        busy = true
        updateControls()
        setStatus(R.string.papers_opening)

        val appContext = requireContext().applicationContext

        viewLifecycleOwner.lifecycleScope.launch {
            var temporaryFile: File? = null

            try {
                // Always use an authenticated Storage download, not a
                // permanent public download URL.
                val bytes = paper.reference.getBytes(MAX_BYTES).await()

                checkSession()

                require(
                    bytes.size >= 5 &&
                        String(bytes, 0, 5, Charsets.US_ASCII) == "%PDF-"
                )

                val file = withContext(Dispatchers.IO) {
                    val directory = File(
                        appContext.cacheDir,
                        "shared-papers"
                    )

                    check(directory.exists() || directory.mkdirs())

                    File.createTempFile(
                        "past-paper-",
                        ".pdf",
                        directory
                    ).also {
                        temporaryFile = it
                        it.writeBytes(bytes)
                    }
                }

                checkSession()

                val contentUri = FileProvider.getUriForFile(
                    appContext,
                    "${appContext.packageName}.papers",
                    file
                )

                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(contentUri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    clipData = android.content.ClipData.newRawUri(
                        "Past paper",
                        contentUri
                    )
                }

                startActivity(intent)

                // Keep the temporary file available to the PDF reader.
                temporaryFile = null

                view?.findViewById<TextView>(R.id.papers_status)
                    ?.text = ""
            } catch (e: CancellationException) {
                throw e
            } catch (_: ActivityNotFoundException) {
                setStatus(R.string.papers_no_viewer)
            } catch (_: Exception) {
                setStatus(R.string.papers_failed)
            } finally {
                temporaryFile?.delete()
                busy = false
                updateControls()
            }
        }
    }
}
