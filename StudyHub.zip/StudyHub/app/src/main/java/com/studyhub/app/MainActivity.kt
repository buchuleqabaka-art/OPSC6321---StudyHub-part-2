package com.studyhub.app

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.studyhub.app.databinding.ActivityMainBinding
import com.studyhub.app.notifications.PushRegistration
import com.studyhub.app.ui.navigation.Routes
import com.studyhub.app.ui.navigation.StudyHubNavigator
import com.studyhub.app.ui.screens.CalendarFragment
import com.studyhub.app.ui.screens.ChatFragment
import com.studyhub.app.ui.screens.GroupDetailFragment
import com.studyhub.app.viewmodel.MainViewModel
import com.studyhub.app.ui.screens.GroupsFragment
import com.studyhub.app.ui.screens.AttendanceFragment
import com.studyhub.app.ui.screens.PollsFragment
import com.studyhub.app.ui.screens.HomeFragment
import com.studyhub.app.ui.screens.LoginFragment
import com.studyhub.app.ui.screens.PastPapersFragment
import com.studyhub.app.ui.screens.ProfileFragment
import com.studyhub.app.ui.screens.RegisterFragment
import com.studyhub.app.ui.screens.SessionsFragment
import com.studyhub.app.ui.screens.TasksFragment
import com.studyhub.app.ui.screens.WelcomeFragment
import com.studyhub.app.viewmodel.AuthViewModel
import com.studyhub.app.viewmodel.SettingsViewModel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity(), StudyHubNavigator {
    private lateinit var binding: ActivityMainBinding
    private val authViewModel: AuthViewModel by viewModels()
    private val settingsViewModel: SettingsViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    private var currentRoute: String = ""
    private var pushRegistrationRequested = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomNavigation.setOnItemSelectedListener { item ->
            mainViewModel.selectPlanningGroup(null)
            val route = when (item.itemId) {
                R.id.nav_groups -> Routes.GROUPS
                R.id.nav_tasks -> Routes.TASKS
                R.id.nav_sessions -> Routes.SESSIONS
                R.id.nav_profile -> Routes.PROFILE
                else -> Routes.HOME
            }
            navigate(route, clearBackStack = true)
            true
        }

        supportFragmentManager.addOnBackStackChangedListener {
            val visible = supportFragmentManager.findFragmentById(R.id.fragment_container)
            visible?.tag?.let { currentRoute = it }
            updateNavigationChrome()
        }

        if (savedInstanceState == null) {
            navigate(Routes.WELCOME, clearBackStack = true)
        } else {
            currentRoute = supportFragmentManager.findFragmentById(R.id.fragment_container)?.tag
                ?: Routes.WELCOME
            updateNavigationChrome()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    authViewModel.state.collect { state ->
                        if (!state.signedIn) pushRegistrationRequested = false
                        if (state.signedIn && settingsViewModel.state.value.notifications && !pushRegistrationRequested) {
                            pushRegistrationRequested = true
                            launch { PushRegistration.register(this@MainActivity) }
                        }
                    }
                }
                launch {
                    settingsViewModel.state.collect { state ->
                        if (!state.notifications) pushRegistrationRequested = false
                        if (state.notifications && authViewModel.state.value.signedIn && !pushRegistrationRequested) {
                            pushRegistrationRequested = true
                            launch { PushRegistration.register(this@MainActivity) }
                        }
                        val requestedMode = if (state.darkMode) {
                            AppCompatDelegate.MODE_NIGHT_YES
                        } else {
                            AppCompatDelegate.MODE_NIGHT_NO
                        }
                        if (AppCompatDelegate.getDefaultNightMode() != requestedMode) {
                            AppCompatDelegate.setDefaultNightMode(requestedMode)
                        }
                    }
                }
            }
        }
    }

    override fun navigate(route: String, clearBackStack: Boolean) {
        if (!::binding.isInitialized || isFinishing || isDestroyed) return
        if (clearBackStack) {
            if (supportFragmentManager.backStackEntryCount > 0) {
                supportFragmentManager.popBackStack(
                    null,
                    androidx.fragment.app.FragmentManager.POP_BACK_STACK_INCLUSIVE
                )
            }
        } else if (currentRoute == route) {
            return
        }

        val fragment = when (route) {
            Routes.WELCOME -> WelcomeFragment()
            Routes.LOGIN -> LoginFragment()
            Routes.REGISTER -> RegisterFragment()
            Routes.HOME -> HomeFragment()
            Routes.ATTENDANCE -> AttendanceFragment()
            Routes.POLLS -> PollsFragment()
            Routes.GROUP_DETAIL -> GroupDetailFragment()
            Routes.GROUPS -> GroupsFragment()
            Routes.TASKS -> TasksFragment()
            Routes.CALENDAR -> CalendarFragment()
            Routes.SESSIONS -> SessionsFragment()
            Routes.CHATS -> ChatFragment()
            Routes.PROFILE -> ProfileFragment()
            Routes.PAST_PAPERS, Routes.PAPERS -> PastPapersFragment()
            else -> WelcomeFragment()
        }

        val transaction = supportFragmentManager.beginTransaction()
            .setReorderingAllowed(true)
            .replace(R.id.fragment_container, fragment, route)
        if (!clearBackStack && currentRoute.isNotEmpty()) {
            transaction.addToBackStack(route)
        }
        currentRoute = route
        transaction.commitAllowingStateLoss()
        updateNavigationChrome()
    }

    private fun updateNavigationChrome() {
        if (!::binding.isInitialized) return
        val mainScreen = currentRoute in MAIN_ROUTES
        binding.bottomNavigation.visibility = if (mainScreen) View.VISIBLE else View.GONE
        val selectedItem = when (currentRoute) {
            Routes.GROUPS -> R.id.nav_groups
            Routes.TASKS -> R.id.nav_tasks
            Routes.SESSIONS -> R.id.nav_sessions
            Routes.PROFILE -> R.id.nav_profile
            else -> R.id.nav_home
        }
        binding.bottomNavigation.menu.findItem(selectedItem)?.isChecked = mainScreen
    }

    companion object {
        private val MAIN_ROUTES = setOf(
            Routes.HOME,
            Routes.GROUPS,
            Routes.TASKS,
            Routes.SESSIONS,
            Routes.PROFILE
        )
    }
}
