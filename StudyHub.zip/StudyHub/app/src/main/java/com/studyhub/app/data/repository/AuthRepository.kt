package com.studyhub.app.data.repository

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.studyhub.app.BuildConfig
import com.studyhub.app.R
import com.studyhub.app.data.model.UserProfile
import com.studyhub.app.util.AuthError
import com.studyhub.app.util.AuthField
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest

/**
 * All authentication goes through here: email/password, Google (Credential
 * Manager) and Apple/iCloud (Firebase OAuth provider). Every method returns a
 * Result so the ViewModel can map failures onto a specific input field.
 */
class AuthRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    companion object {
        private const val TAG = "AuthRepository"
        private const val USERS = "users"
        private const val EMAIL_INDEX = "emailIndex"
    }

    val currentUser: FirebaseUser? get() = auth.currentUser
    fun isLoggedIn(): Boolean = auth.currentUser != null

    // --- Email lookup -------------------------------------------------------

    /**
     * Checks whether an address already belongs to a StudyHub account.
     *
     * We cannot use fetchSignInMethodsForEmail because Firebase's
     * email-enumeration protection makes it return an empty list, and opening up
     * the users collection to unauthenticated reads would leak everyone's email.
     * Instead every registration writes a document to emailIndex keyed by the
     * SHA-256 of the address - readable before sign-in, but it contains no
     * personal data and cannot be reversed into an email list.
     */
    suspend fun emailExists(email: String): Boolean {
        val key = emailKey(email)
        return try {
            val doc = firestore.collection(EMAIL_INDEX).document(key).get().await()
            val exists = doc.exists()
            Log.d(TAG, "Email index lookup completed: $exists")
            exists
        } catch (e: Exception) {
            Log.w(TAG, "emailExists lookup failed, assuming unknown", e)
            // Offline or rules blocked the read - let the sign-in attempt decide
            true
        }
    }

    /** Adds the address to the lookup index. Stores the hash only, never the email. */
    private suspend fun indexEmail(email: String) {
        runCatching {
            firestore.collection(EMAIL_INDEX)
                .document(emailKey(email))
                .set(mapOf("registered" to true))
                .await()
        }.onFailure { Log.w(TAG, "Could not write email index entry", it) }
    }

    private fun emailKey(email: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(email.trim().lowercase().toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }

    // --- Registration -------------------------------------------------------

    suspend fun register(
        name: String,
        email: String,
        password: String,
        dateOfBirth: String,
        qualification: String = "Information Technology",
        yearOfStudy: String = "1st Year"
    ): Result<UserProfile> {
        val cleanEmail = email.trim().lowercase()
        val cleanName = name.trim()
        val cleanCourse = qualification.trim().ifBlank { "Information Technology" }
        val cleanYear = yearOfStudy.trim().ifBlank { "1" }
        val formattedYear = if (cleanYear.all { it.isDigit() }) {
            when (cleanYear) {
                "1" -> "1st Year"
                "2" -> "2nd Year"
                "3" -> "3rd Year"
                else -> "${cleanYear}th Year"
            }
        } else cleanYear

        return try {
            // Firebase hashes the password with scrypt server-side; the raw value
            // never leaves this call and is never persisted by the app.
            Log.d(TAG, "Creating an account")
            val result = auth.createUserWithEmailAndPassword(cleanEmail, password).await()
            val uid = result.user?.uid ?: return Result.failure(
                IllegalStateException("Firebase returned no user")
            )

            val profile = UserProfile(
                uid = uid,
                name = cleanName,
                email = cleanEmail,
                dateOfBirth = dateOfBirth.trim(),
                course = cleanCourse,
                yearOfStudy = formattedYear,
                provider = "password"
            )
            firestore.collection(USERS).document(uid).set(profile).await()
            indexEmail(cleanEmail)
            // User must manually log in after creating an account
            auth.signOut()
            Result.success(profile)
        } catch (e: FirebaseAuthUserCollisionException) {
            Result.failure(AuthException(AuthError(AuthField.EMAIL, R.string.error_email_exists)))
        } catch (e: FirebaseAuthWeakPasswordException) {
            Result.failure(AuthException(AuthError(AuthField.PASSWORD, R.string.error_password_weak)))
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            Result.failure(AuthException(AuthError(AuthField.EMAIL, R.string.error_email_not_valid)))
        } catch (e: Exception) {
            Log.e(TAG, "Registration failed", e)
            Result.failure(AuthException(AuthError(AuthField.GENERAL, friendlyMessage(e))))
        }
    }

    // --- Email / password login --------------------------------------------

    suspend fun login(email: String, password: String): Result<UserProfile> {
        val cleanEmail = email.trim().lowercase()
        return try {
            val result = auth.signInWithEmailAndPassword(cleanEmail, password).await()
            val uid = result.user?.uid ?: return Result.failure(
                IllegalStateException("Firebase returned no user")
            )
            Result.success(loadOrCreateProfile(uid, cleanEmail, result.user?.displayName.orEmpty(), "password"))
        } catch (e: FirebaseAuthInvalidUserException) {
            // No account for this address - flag the email field, not the password
            Result.failure(AuthException(AuthError(AuthField.EMAIL, R.string.error_email_unregistered)))
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            // Could be a bad password OR a non-existent account when enumeration
            // protection is on, so ask Firestore which one it actually is.
            val known = emailExists(cleanEmail)
            if (!known) {
                Result.failure(AuthException(AuthError(AuthField.EMAIL, R.string.error_email_unregistered)))
            } else {
                Result.failure(AuthException(AuthError(AuthField.PASSWORD, R.string.error_incorrect_password)))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Login failed", e)
            Result.failure(AuthException(AuthError(AuthField.GENERAL, friendlyMessage(e))))
        }
    }

    // --- Continue with Google ----------------------------------------------

    /**
     * Uses Credential Manager (the replacement for the deprecated
     * GoogleSignInClient) to fetch an ID token, then trades it for a Firebase
     * credential.
     */
    suspend fun signInWithGoogle(context: Context): Result<UserProfile> {
        return try {
            val activity = (context as? android.app.Activity)
                ?: (context as? android.content.ContextWrapper)?.baseContext as? android.app.Activity
                ?: context

            val googleIdOption = try {
                GetSignInWithGoogleOption.Builder(serverClientId = BuildConfig.GOOGLE_WEB_CLIENT_ID)
                    .build()
            } catch (_: Exception) {
                GetGoogleIdOption.Builder()
                    .setFilterByAuthorizedAccounts(false)
                    .setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID)
                    .setAutoSelectEnabled(false)
                    .build()
            }

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val response = CredentialManager.create(activity).getCredential(
                context = android.content.MutableContextWrapper(activity),
                request = request
            )
            val credential = response.credential

            if (credential !is CustomCredential ||
                credential.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                return Result.failure(AuthException(AuthError(AuthField.GENERAL, R.string.error_google_credential)))
            }

            val googleCredential = GoogleIdTokenCredential.createFrom(credential.data)
            val idToken = googleCredential.idToken
            if (idToken.isBlank()) {
                return Result.failure(AuthException(AuthError(AuthField.GENERAL, R.string.error_google_credential)))
            }

            val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
            val result = auth.signInWithCredential(firebaseCredential).await()
            val user = result.user ?: return Result.failure(
                IllegalStateException("Firebase returned no user")
            )

            Result.success(
                loadOrCreateProfile(
                    uid = user.uid,
                    email = user.email.orEmpty(),
                    name = googleCredential.displayName ?: user.displayName.orEmpty(),
                    provider = "google.com",
                    photoUrl = googleCredential.profilePictureUri?.toString().orEmpty()
                )
            )
        } catch (e: GetCredentialException) {
            Log.e(TAG, "Google Sign-in failed: ${e.type} - ${e.message}", e)
            val isCancelled = e is GetCredentialCancellationException ||
                e.type.contains("Cancellation", ignoreCase = true) ||
                e.message?.contains("cancel", ignoreCase = true) == true
            val errorMessage = if (isCancelled) {
                R.string.error_google_cancelled
            } else {
                R.string.error_google_configuration
            }
            Result.failure(AuthException(AuthError(AuthField.GENERAL, errorMessage)))
        } catch (e: Exception) {
            Log.e(TAG, "Google sign-in failed with unexpected error", e)
            Result.failure(AuthException(AuthError(AuthField.GENERAL, friendlyMessage(e))))
        }
    }


    // --- Password reset and sign out ---------------------------------------

    suspend fun sendPasswordReset(email: String): Result<Unit> {
        val cleanEmail = email.trim().lowercase()
        if (!emailExists(cleanEmail)) {
            return Result.failure(
                AuthException(AuthError(AuthField.EMAIL, R.string.error_not_registered))
            )
        }
        return try {
            auth.sendPasswordResetEmail(cleanEmail).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(AuthException(AuthError(AuthField.GENERAL, friendlyMessage(e))))
        }
    }

    fun signOut() {
        Log.d(TAG, "Signing out current account")
        auth.signOut()
    }

    suspend fun currentProfile(): UserProfile? {
        val uid = auth.currentUser?.uid ?: return null
        return try {
            firestore.collection(USERS).document(uid).get().await().toObject(UserProfile::class.java)
        } catch (e: Exception) {
            Log.e(TAG, "Could not load profile", e)
            null
        }
    }

    // --- Helpers ------------------------------------------------------------

    private suspend fun loadOrCreateProfile(
        uid: String,
        email: String,
        name: String,
        provider: String,
        photoUrl: String = ""
    ): UserProfile {
        return try {
            val doc = firestore.collection(USERS).document(uid)
            val existing = doc.get().await().toObject(UserProfile::class.java)
            if (existing != null) return existing

            // First social sign-in: build the profile document now
            val profile = UserProfile(
                uid = uid,
                name = name.ifBlank { email.substringBefore("@") },
                email = email.lowercase(),
                photoUrl = photoUrl,
                provider = provider
            )
            doc.set(profile).await()
            if (email.isNotBlank()) indexEmail(email)
            profile
        } catch (e: Exception) {
            Log.w(TAG, "Failed to load/save profile in Firestore, returning local fallback profile", e)
            UserProfile(
                uid = uid,
                name = name.ifBlank { email.substringBefore("@") },
                email = email.lowercase(),
                photoUrl = photoUrl,
                provider = provider
            )
        }
    }

    private fun friendlyMessage(e: Exception): Int = when {
        e.message?.contains("network", ignoreCase = true) == true ->
            R.string.error_network
        e.message?.contains("permission-denied", ignoreCase = true) == true ||
        e.message?.contains("permission denied", ignoreCase = true) == true ->
            R.string.error_firestore_permission
        e.message?.contains("web client id", ignoreCase = true) == true ->
            R.string.error_google_configuration
        else -> R.string.error_generic
    }

}

/** Carries the field-specific error up to the UI layer. */
class AuthException(val error: AuthError) : Exception()