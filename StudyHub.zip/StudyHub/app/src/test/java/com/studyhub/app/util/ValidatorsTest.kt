package com.studyhub.app.util

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ValidatorsTest {

    @Test
    fun testQualificationValidation() {
        assertTrue(Validators.isValidQualification("Computer Science"))
        assertTrue(Validators.isValidQualification("BSc Information Technology"))
        assertFalse(Validators.isValidQualification(""))
        assertFalse(Validators.isValidQualification(" "))
        assertFalse(Validators.isValidQualification("A"))
    }

    @Test
    fun testYearOfStudyValidation() {
        assertTrue(Validators.isValidYearOfStudy("1"))
        assertTrue(Validators.isValidYearOfStudy("3"))
        assertTrue(Validators.isValidYearOfStudy("8"))
        assertFalse(Validators.isValidYearOfStudy("0"))
        assertFalse(Validators.isValidYearOfStudy("9"))
        assertFalse(Validators.isValidYearOfStudy("-1"))
        assertFalse(Validators.isValidYearOfStudy("abc"))
        assertFalse(Validators.isValidYearOfStudy(""))
    }

    @Test
    fun testAccreditedEmailValidation() {
        assertTrue(Validators.isValidAccreditedEmail("student@university.edu"))
        assertTrue(Validators.isValidAccreditedEmail("student@uct.ac.za"))
        assertTrue(Validators.isValidAccreditedEmail("student@ox.ac.uk"))
        assertTrue(Validators.isValidAccreditedEmail("student@unimelb.edu.au"))
        assertTrue(Validators.isValidAccreditedEmail("student@varsitycollege.co.za"))
        assertFalse(Validators.isValidAccreditedEmail("user@gmail.com"))
        assertFalse(Validators.isValidAccreditedEmail("user@yahoo.com"))
        assertFalse(Validators.isValidAccreditedEmail("0821234567"))
        assertFalse(Validators.isValidAccreditedEmail(""))
    }
}
