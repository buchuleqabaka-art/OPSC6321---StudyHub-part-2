package com.studyhub.app
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
@RunWith(AndroidJUnit4::class)
class FeatureStorageTest {
    @Test fun appLaunchesWithoutAConfiguredApi() {
        androidx.test.core.app.ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            scenario.onActivity { activity -> assertNotNull(activity.findViewById<android.view.View>(R.id.fragment_container)) }
        }
    }

    @Test fun newFeatureLayoutsInflate() {
        val context = android.view.ContextThemeWrapper(InstrumentationRegistry.getInstrumentation().targetContext,R.style.Theme_StudyHub)
        InstrumentationRegistry.getInstrumentation().runOnMainSync {
            val inflater=android.view.LayoutInflater.from(context)
            for(layout in listOf(R.layout.fragment_engagement,R.layout.fragment_chat,R.layout.fragment_sessions)) assertNotNull(inflater.inflate(layout,null))
        }
    }
}

